create table acc
(
        accID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
	accName	VarChar(50) null
);

create table insulin
(
	insulinID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
	Insulin VarChar(50) null
	
);

create table dosage
(
    	dosageID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
	Dosage VarChar(50) null
);

create table blood
(
	readID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
	Day 		VarChar(30) null,
	ReadDate	Date        null,
	ReadTime	VarChar(6)  null,
	Reading		VarChar(15) null,
	Medication	VarChar(25) null,
	Dosage		VarChar(25) null
);			
