create table diary
(
	DiaryID		integer primary key autoincrement,
	DMonth		varchar,
	DDay		varchar,
	DDate		date,
	DNotes		text
);

create table pim
(
	PimID		integer primary key autoincrement,
	FullName	varchar,
	Address		varchar,
	SuburbTown	varchar,
	State		varchar,
	PostCode	varchar,
	Phone		varchar,
	Fax		varchar,
	Mobile		varchar,
	Email		varchar,
	WebAddress	varchar,
	Picture		blob,
	Notes		text
);

create table pswd
(
	passwdID	integer primary key autoincrement,
	aPassword	varchar
);
