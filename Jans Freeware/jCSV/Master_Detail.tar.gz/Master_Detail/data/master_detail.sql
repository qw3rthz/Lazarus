BEGIN TRANSACTION;
CREATE TABLE cust 
(
	ID Integer PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL, 
	CustName VarChar(60) null, 
	Addr VarChar(70) null, 
	Suburb VarChar(70) null, 
	postCode Varchar(15) null, 	
	custState VarChar(15) null
);

CREATE TABLE sales 
(
	ID Integer PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
	custID Integer null,
	itemNum VarChar(25) null, 
	saleDate Date null, 
	shipDate Date null, 
	item VarChar(60) null, 
	price Numeric(6,2) null
);

CREATE TABLE stock 
(
	ID Integer PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL, 
	item VarChar(60) null, 
	price Numeric(6,2) null, 
	itemNum VarChar(25) null
);

