default password is 9999
